<footer id="contact" role="contentinfo" class="content-info">
  <div class="row">
    <div class="small-12 columns">
      <p>2015 &copy; kyletolie.com</p>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
