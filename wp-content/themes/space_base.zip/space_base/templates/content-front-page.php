<article <?php post_class(); ?>>
  <header>
	<?php the_post_thumbnail(); ?>
  </header>
</article>